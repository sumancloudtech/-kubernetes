[<<back](index.md)  
Installation on Ubuntu

```bash
# install azure-cli

sudo apt-get install nodejs-legacy
sudo apt-get install npm
sudo npm install -g azure-cli
```
Login

```bash
# This will output an url and a device code for you to use browser to login  
azure login

# This will prompt for your password in the console
azure login -u <your organizational ID email address>

# This will login in using a service principal
azure login -u "<service-principal-id>" -p "<key>" --service-principal --tenant "<tenant-id>"
```

Usage

```bash
#!/usr/bin/env bash
az [ group ] [ subgroup ] [ command ] {parameters}
```

Resources

```bash
# find images with Linux in name
azure vm image list | grep "Linux"

# create a new VM (in asm mode)
azure vm create ${vm_name} ${image_name} -u ${azureuser} -p "${password}" -z "Small" -e -l "West US"

# List VMs disks
azure vm disk list

# Remove all disks of VMs labeled with LABEL
for disk in $(azure vm disk list | grep LABEL | awk '{print $2}')
do 
    azure vm disk delete --blob-delete "$disk"
done

# Create storage account $myacct in location 'West US'
azure storage account create ${storage_account} --label ${storage_account} --location 'West US'

# Set default account environment variables
export AZURE_STORAGE_ACCOUNT=$account_name
export AZURE_STORAGE_ACCESS_KEY=$account_key

# Create a VM image based on a storage file
azure vm image create ${image_name} \
  --os linux  -l 'West Europe' \
  --blob-url https://${storage_account}.blob.core.windows.net:443/vms/${image_name}.vhd \
  -v

# Share a file (a vm image for example) with the world:
azure storage blob sas create -a ${storage_account} --container ${container} --blob ${filename} --permissions r

# Download a file from a blob storage using curl/wget
# values of the header variables can be calculated like here: https://gist.github.com/jrwren/ff46f4ba177f042ccdc48c080c198f60
curl -v \
  -H "$x_ms_date_h" \
  -H "$x_ms_version_h" \
  -H "$authorization_header" \
"$URL"
```
